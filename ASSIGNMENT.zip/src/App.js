import React from 'react';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import  Home  from './components/home/Home';
import  Giphy  from './components/giphy/Giphy';

import './App.css'

function App() {
  return (
    <Router>
      <div>
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/giphy">Giphy</Link>
          </li>
        </ul>
        <hr />

        <Route exact path="/" component={Home} />
        <Route path="/giphy" component={Giphy} />
        {/* <Route path="/topics" component={Topics} /> */}
      </div>
    </Router>
  );
}

export default App;
