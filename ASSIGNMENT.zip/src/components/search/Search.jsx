import React, {Component} from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import InputBase from '@material-ui/core/InputBase';
import IconButton from '@material-ui/core/IconButton';
import SearchIcon from '@material-ui/icons/Search';

const styles = {
  root: {
    padding: '2px 4px',
    display: 'flex',
    alignItems: 'center',
    width: 400,
  },
  input: {
    marginLeft: 8,
    flex: 1,
  },
  iconButton: {
    padding: 10,
  },
  divider: {
    width: 1,
    height: 28,
    margin: 4,
  },
};

class SearchComponent extends React.Component{
    constructor(props){
      super(props);
      this.state={ 
        query:'',
        data:''
      }
    }
    handleChange=(e)=>{
      console.log('dgcghsc',this.state.query);
      this.setState({
        [e.target.name]:e.target.value
      })
      // this.setTimeout(() => {
      //   this.search(this.state.query);
      // }, 3000);
      // https://api.giphy.com/v1/gifs/search?api_key=swyjDFARATIOQwWiry8Yp5qIYnt67YjT
    }
    onSearch=()=>{
    const url = `https://api.giphy.com/v1/gifs/search?api_key=swyjDFARATIOQwWiry8Yp5qIYnt67YjT&q=${this.state.query}&limit=5&offset=0&rating=G&lang=en`;
    const token = {};
    this.token = token;

    fetch(url)
      .then(results => results.json())
      .then(data => {
        console.log(data);
        // if (this.token === token) {
          this.setState({ data: data.results });
        // }
      });
    }
render(){
    return (
      <div>
        <Paper className={this.props.classes.root} elevation={1}>
          <InputBase className={this.props.classes.input} placeholder="Search Giphy" onChange={this.handleChange} name='query'/>
          <IconButton className={this.props.classes.iconButton} aria-label="Search" onClick={this.onSearch}>
            <SearchIcon />
          </IconButton>
        </Paper>
        {this.state.data!=''?
        this.state.data.map((giphy)=>{
          return(
          <div>
            <image url={giphy.url}/>
          </div>
          );
        })  :<div>Nothing to display</div>
        }
      </div>
    );
  }
}

SearchComponent.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(SearchComponent);
