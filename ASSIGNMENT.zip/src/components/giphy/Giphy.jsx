import React, { Component } from 'react';
import SearchComponent from "../search/Search";
// swyjDFARATIOQwWiry8Yp5qIYnt67YjT
export default class Giphy extends Component {
  handleChange=(e)=>{
    console.log(e);
  }
  render() {
    return (
      <div>
        <SearchComponent handleChange={this.handleChange}/>
      </div>
    )
  }
}
