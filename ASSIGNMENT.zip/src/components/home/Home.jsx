import React, { Component } from 'react' 
import DrawerComponent from '../drawer/drawerComponent'
export default class Home extends Component {
  state={
    curTime:''
  }
    componentDidMount() {
        setInterval( () => {
          this.setState({
            curTime : new Date().toLocaleString()
          })
        },1000)
      }
  render() {
    var date = new Date().getDate().toString(); //Current Date
    var month = new Date().getMonth() + 1; //Current Month
    var year = new Date().getFullYear().toString(); //Current Year
    let Datevalue =  date +'/' + month.toString() + '/' + year;
    var time = new Date(); //Current Month
    var hours = time.getHours(); //Current Hours
    var min = time.getMinutes(); //Current Minutes
    var sec = time.getSeconds(); //Current Seconds
    // var year = new Date().getFullYear();
    // let time= this.state.curTime;
    return (
      <div>
        {hours}:{min}:{sec}
        <DrawerComponent date={Datevalue}/> 
      </div>
    )
  }
}
